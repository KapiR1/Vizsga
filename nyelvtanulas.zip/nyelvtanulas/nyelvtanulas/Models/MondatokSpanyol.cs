﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace nyelvtanulas.Models;

public partial class MondatokSpanyol
{
    public int Id { get; set; }

    public string? SpanyolMondatok { get; set; }
    [JsonIgnore]
    public virtual MondatokMagyar IdNavigation { get; set; } = null!;
}
