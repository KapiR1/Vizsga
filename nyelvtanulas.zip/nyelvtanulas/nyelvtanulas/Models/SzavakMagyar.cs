﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace nyelvtanulas.Models;

public partial class SzavakMagyar
{
    public int Id { get; set; }

    public string MagyarSzo { get; set; } = null!;
    [JsonIgnore]
    public virtual SzavakSpanyol IdNavigation { get; set; } = null!;
}
