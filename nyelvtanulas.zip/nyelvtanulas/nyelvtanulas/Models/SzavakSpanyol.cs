﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace nyelvtanulas.Models;

public partial class SzavakSpanyol
{
    public int Id { get; set; }

    public string SpanyolSzo { get; set; } = null!;
    [JsonIgnore]
    public virtual SzavakMagyar? SzavakMagyar { get; set; }
}
