﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace nyelvtanulas.Models;

public partial class MondatokMagyar
{
    public int Id { get; set; }

    public string? MagyarMondatok { get; set; }
    [JsonIgnore]
    public virtual MondatokSpanyol? MondatokSpanyol { get; set; }
}
